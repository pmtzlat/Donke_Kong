class Floor:
    def __init__(self, x, y, w):
        self.x = x
        self.y = y
        self.w = w
