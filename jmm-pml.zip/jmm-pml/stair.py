class Stair:
    def __init__(self, x, y, h):
        self.x = x
        self.y = y
        self.h = h
        
            