import random
class Barrel:
    def __init__(self, x, y, k, f):
        self.x= x
        self.y = y
        self.k = k
        self.f = f
        self.limitY = 22
        self.velocityX = 2
        self.velocityY = 2
        self.base1 = 216
        self.base2 = 176
        self.base3 = 138
        self.base4 = 100
        self.base5 = 62
        self.base6 = 25
        self.probability = False

        
    def moveX(self):
        'Setting the variable that does the probability of the barrel falling. It is True 1/4 of the time by calculating a random integer between 1 and 4'
        self.probability = random.randint(1,4)==4
        
        '''setting velocity so it switches from left to right changing the value of the velocity as a vector. If the barrel's x is 190 or its y
        is on a specific set of platforms it will go left,
        if its x is 0 or its y is on a specific set of platofrms it will go right.'''
        if self.x==190 or self.y == 60 or self.y == 136 or self.y==214:
            self.velocityX = -2
        if self.x==0 or self.y == 98 or self.y == 174:
            self.velocityX = 2
            
        '''making barrels fall vertically off ladders and landing on the platform below by claculating probabilities, and if its true, they fall,
        with their velocity along the x axis being 0'''
        if self.x == 144 and self.y == 22 and self.probability==True:
            self.y += 2
            self.velocityX = 0
            self.limitY = 60            
        if (self.x == 64 or self.x == 32) and self.y == 60 and self.probability==True:
            self.y += 2
            self.velocityX = 0
            self.limitY = 98     
        if (self.x == 96 or self.x == 160) and self.y == 98 and self.probability==True:
            self.y += 2
            self.velocityX = 0
            self.limitY = 136       
        if (self.x == 32 or self.x == 144) and self.y == 136 and self.probability==True:
            self.y += 2
            self.velocityX = 0
            self.limitY = 174
        if (self.x == 80 or self.x == 160) and self.y == 174 and self.probability==True:
            self.y += 2
            self.velocityX = 0
            self.limitY = 214
            
        

            
            
        '''The actual movement along the x axis is made by adding the value of the velocity to the x coordinate'''
        self.x += self.velocityX
            
    def moveY(self):
        '''Calculating the effect of gravity based on having values that if the barrel's x is something and the barrel's
        y is a specific value, it stops falling, as it is on top of a platform'''
        if (self.limitY - self.y) > 1:
            self.y += self.velocityY
        elif (self.limitY - self.y) ==  1:
            self.y += 1
        
        if (self.base1 >= self.y >= self.base2-1) or (self.base2 >= self.y >= self.base3 and self.x>174):
            self.limitY = 214
        elif (self.base3 <= self.y <= self.base2-1) or (self.base3 >= self.y >= self.base4 and self.x<=18):
            self.limitY = 174
        elif (self.base4 <= self.y <= self.base3-1) or (self.base4 >= self.y >= self.base5 and self.x>174):
            self.limitY = 136
        elif (self.base5 <= self.y <= self.base4-1) or (self.base5 >= self.y >= self.base6 and self.x<=18):
            self.limitY = 98
        elif (self.base6 <= self.y <= self.base5-1) or (self.base6 >= self.y  and self.x > 160):
            self.limitY = 60
        elif (self.y <= self.base6-1):
            self.limitY = 22
            
    def start(self):
        'Executes the barrels methods'
        self.moveX()
        self.moveY()
        
                