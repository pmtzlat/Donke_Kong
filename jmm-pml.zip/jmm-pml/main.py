import pyxel
import random
from luigi import Luigi
from stair import Stair
from barrel import Barrel
from floor import Floor



class Game:
    
    def __init__(self):
        self.luigiX = 14
        self.luigiY = 214
        self.limitLuigiY = 214
        self.plusY = 0
        self.globalLives=3
        self.stairCondition=False
        self.jumpingCondition=False
        self.luigi = Luigi(self.luigiX, self.luigiY,self.limitLuigiY, self.plusY, self.globalLives, self.stairCondition)
        self.stair = [Stair(163,193,40),Stair(35,155,40),Stair(163,116,40), Stair(35,83,35),Stair(147,44,40),
                      Stair(83,195,11), Stair(83,223,10), Stair(147,154,15), Stair(147,186,10), Stair(99,122,7),
                      Stair(99,146,7), Stair(67,83,7), Stair(67,109,7),Stair(90,16,30)]
        self.floor = [Floor(0,230,208), Floor(0,190,176), Floor(32,152,208),Floor(0,114,176),Floor(32,76,208),Floor(0,38,160),Floor(50,16,50)]
        self.barrel= []
        self.luigiDirection="right"
        self.state='alive'
        self.menuScreen=True
        self.gameScreen=False
        self.dieScreen=False
        self.winScreen=False
        self.width= 200
        self.height = 240
        self.donkey_is_active = []
        self.score = 0
    
        pyxel.init(self.width, self.height,fps=30)
        pyxel.load("assets/assetsObjects.pyxres")
        pyxel.playm(0, loop = True)
        pyxel.run(self.update, self.draw)
        
    
    def barrelsSet(self):
        '''Method that is used to append a new barrel in the list every randomly frame range.'''
        if len(self.barrel)<=9:
            if pyxel.frame_count%(random.randrange(40,100,20))==0 and pyxel.frame_count>30:
                self.barrel.append(Barrel(40,22,False,random.randint(1,4)))
                self.donkey_is_active = [True,pyxel.frame_count]
        '''Here, for each barrel in the list will check if it is at the oil container.
        If true then this barrel will be removed from the list.'''
        for b in self.barrel:
            b.start()
            if b.x == 2 and b.y == 214:
                self.barrel.remove(b)
                
    def jumpingSet(self):
        '''Method that alows luigi to jump. If key Up is pressed and Luigi is touching the platform then it will be allowed to jump.'''
        if (
            pyxel.btnp(pyxel.KEY_UP, hold=1)
            and self.limitLuigiY-1 <= self.luigiY <= self.limitLuigiY+1
            and self.stairCondition == False
            ):
                self.plusY = -8
        elif self.plusY != 0:
            self.luigiY, self.plusY = self.luigi.jump(self.luigiY, self.plusY)
            
        '''Here we are setting the value jumpingContidition True or False, whenever he touches or not the floor'''
        if self.luigiY == self.limitLuigiY:
            self.jumpingCondition=False
        else:
            self.jumpingCondition = True
        if self.stairCondition == True:
            self.jumpingCondition = False
                
    def stairsSet(self):
        'method that detects if luigi is in a stair'
        self.stairCondition = self.luigi.setStair(self.luigiX, self.luigiY, self.limitLuigiY,self.jumpingCondition)
        'If he is in a stair then we can press up to climb trought it, calling the method clib of Luigi'
        if self.stairCondition == True:
            if pyxel.btn(pyxel.KEY_UP):
                self.luigiY= self.luigi.climb('up',self.luigiY)
            elif pyxel.btn(pyxel.KEY_DOWN):
                self.luigiY= self.luigi.climb('down',self.luigiY)
                
    def scoreSystem(self):
        '''Method that detects luigis position and adds points to the score. For each barrel checks the position respectibly with Luigi'''
        for b in self.barrel:
            if b.x<=self.luigiX<=b.x+11 and b.y-30<=self.luigiY<=b.y and b.k == False:
                self.score += 100
                b.k = True
                
    def gravitySet(self):
        '''Method that detects if luigi is in the air and activates gravity'''
        if self.luigiY <= self.limitLuigiY and self.stairCondition == False:
            self.luigiY, self.limitLuigiY = self.luigi.gravity(self.luigiX, self.luigiY)
            
            
    def movingSet(self):
        '''Method to be able to move mario with the keys of the keyboard (Right and Left)'''
        if pyxel.btn(pyxel.KEY_RIGHT) and self.luigiX<186:
            self.luigiX = self.luigi.move('right')
            self.luigiDirection = 'right'
        elif pyxel.btn(pyxel.KEY_LEFT)and self.luigiX>0:
            self.luigiX = self.luigi.move('left')
            self.luigiDirection= 'left'
            
    def kill(self):
        '''Method that makes mario die and get less one live whenever he touches a barrel'''
        for b in self.barrel:
            if b.y-8 <= self.luigiY <= b.y+8 and b.x-8 <= self.luigiX <= b.x+8:
                self.state='death'
                self.barrel.clear()
                self.restartLuigi()
        '''If a barrel kills Luigi then it will lose a life, setting again the state to alive'''
        if self.state == 'death':
            self.globalLives-=1
            self.state = 'alive'
            
    def restartLuigi(self):
        '''Function that sets luigi at the starting position whenever he dies'''
        self.luigiX = 16
        self.luigiY = 214
        self.limitLuigiY = 214
        self.plusY = 0
        self.stairCondition=False
        self.jumpingCondition=False
        self.luigi = Luigi(self.luigiX, self.luigiY,self.limitLuigiY, self.plusY, self.globalLives, self.stairCondition)
        
    def restartGame(self):
        '''Function that is use to restart the game as wanted. It is used whenever he looses all his lives or he wins the game'''

        self.restartLuigi()
        self.globalLives=3
        self.score = 0
        self.luigiDirection="right"
        self.state='alive'
        self.barrel.clear()

        
    def update(self):
        '''QUIT THE GAME IF Q IS PRESSED'''
        #QUIT
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()
        '''Here we call al the method writen before so they execute every frame'''
        ##Methods
        if self.gameScreen== True and self.menuScreen == False:
            self.limitLuigiY = self.luigi.setLimit(self.luigiX,self.luigiY)
            self.barrelsSet()
            self.movingSet()
            self.gravitySet()
            self.jumpingSet()
            self.stairsSet()
            self.scoreSystem()
            self.kill()
            '''Here if luigi looses all his lives then it will switch to the dieScreen, turning off the gameScreen.'''
            if self.globalLives<0:
                self.gameScreen, self.dieScreen=False, True
            '''Here if luigi gets to the princess then it will switch to the winScreen, turning off the gameScreen.'''
            if self.luigiY <= 25 and self.luigiX <= 100:
                self.winScreen,self.gameScreen=True,False
                
            #OTHERS
            '''This code is design so if any error occurs with the limit or with any pyxel, luigi's Y will be adjust.'''
            if self.luigiY>self.limitLuigiY:
                self.luigiY = self.limitLuigiY-1
            if self.stairCondition== False and (self.limitLuigiY - self.luigiY) ==  1:
                self.luigiY += 1
            
    
    def draw(self):
        
        pyxel.cls(0)
        ##MAIN MENU
        '''Here we define the menu screen, is what the user will se first. If we click SPACE key then it will
        switch of to the game Screen.'''
        if self.menuScreen == True:
            pyxel.blt(60,70,0,80,9,80,33)
            if pyxel.frame_count%20<10:
                pyxel.blt(70,110,0,48,64,48,32) 
            elif pyxel.frame_count%20>=10:
                pyxel.blt(70,110,0,48,64,-48,32) 
            if pyxel.btn(pyxel.KEY_SPACE):
                self.gameScreen, self.menuScreen = True, False
                
        #GAME SCREEN
        '''Here we define the game Screen, is were all the game and animations are printed.'''
        if self.gameScreen==True:
            '''Score'''
            pyxel.blt(150,3,0,37,8,35,16)
            pyxel.text(158,10,"{:05}".format(self.score),10)
            '''lives'''
            pyxel.text(110,3,"Lives: %i" %(self.globalLives),9)
            
            
            '''Ladders. At the begging of the game, there will be some animating and flashing with the screen.'''
            if 70 > pyxel.frame_count > 0:
                if pyxel.frame_count%5==0:
                    for s in self.stair:
                        pyxel.blt(s.x,s.y,0,99,48,10,s.h)
                if pyxel.frame_count%10==0:
                    for s in self.stair:
                        pyxel.blt(s.x,s.y,0,99,48,10,s.h)
                if pyxel.frame_count%15<0:
                    for s in self.stair:
                        pyxel.blt(s.x,s.y,0,99,48,10,s.h)
                if pyxel.frame_count%20==0:
                    for s in self.stair:
                        pyxel.blt(s.x,s.y,0,99,48,10,s.h)
            else:
                '''After the flasing stairs will be static.'''
                for s in self.stair:
                    pyxel.blt(s.x,s.y,0,99,48,10,s.h)
            
            '''Platform'''
            for p in self.floor:
                pyxel.blt(p.x,p.y,0,0,128,p.w,8)
                
            '''oil bucket(Decoration)'''
            pyxel.blt(0, 198,0,16,16,16,32, colkey=0)
            
            '''characters'''
            #######
            #MARIO#
            #######
            '''Here we set al the animations that mario does when moving. As he walks, climbs and jumps.'''
            if pyxel.btn(pyxel.KEY_RIGHT) and self.luigiY == self.limitLuigiY and self.stairCondition == False and self.jumpingCondition==False:
                if (pyxel.frame_count%16 <=3):
                    pyxel.blt(self.luigiX,self.luigiY,0,32,96,16,16,colkey=0)
                elif(pyxel.frame_count%16 <=7):
                    pyxel.blt(self.luigiX,self.luigiY,0,0,96,16,16,colkey=0)
                elif(pyxel.frame_count%16 <=11):
                    pyxel.blt(self.luigiX,self.luigiY,0,16,96,16,16,colkey=0)
                else:
                     pyxel.blt(self.luigiX,self.luigiY,0,0,96,16,16,colkey=0)
            elif pyxel.btn(pyxel.KEY_LEFT) and self.luigiY == self.limitLuigiY and self.stairCondition ==False and self.jumpingCondition==False:
                if (pyxel.frame_count%16 <=3):
                    pyxel.blt(self.luigiX,self.luigiY,0,32,96,-16,16,colkey=0)
                elif(pyxel.frame_count%16 <=7):
                    pyxel.blt(self.luigiX,self.luigiY,0,0,96,-16,16,colkey=0)
                elif(pyxel.frame_count%16 <=11):
                    pyxel.blt(self.luigiX,self.luigiY,0,16,96,-16,16,colkey=0)
                else:
                     pyxel.blt(self.luigiX,self.luigiY,0,0,96,-16,16,colkey=0)
            elif self.jumpingCondition==True:
                if self.luigiDirection == 'right':
                    pyxel.blt(self.luigiX,self.luigiY,0,32,96,16,16,colkey=0)
                elif self.luigiDirection == 'left':
                    pyxel.blt(self.luigiX,self.luigiY,0,32,96,-16,16,colkey=0)
            elif (pyxel.btn(pyxel.KEY_UP) or pyxel.btn(pyxel.KEY_DOWN)) and self.stairCondition == True:
                if (pyxel.frame_count%8 <= 3):
                    pyxel.blt(self.luigiX,self.luigiY,0,16,112,16,16,colkey=0)
                else:
                    pyxel.blt(self.luigiX,self.luigiY,0,32,112,16,16,colkey=0)
            elif self.stairCondition == True:
                pyxel.blt(self.luigiX,self.luigiY,0,16,112,16,16,colkey=0)
                
            else:
                pyxel.blt(self.luigiX,self.luigiY,0,16,0,16,16,colkey=0)
            
            #########
            #BARRELS#
            #########
            '''Each barrel of the screen will have a diferent animation, starting at the moment that donkey kong troughs it, 
            printing each of them on screen'''
            for b in self.barrel:
                if b.f == 1:
                    pyxel.blt(b.x,b.y+5,0,48,101,11,11,colkey=0)
                    if pyxel.frame_count%4 ==0:
                        b.f = 2
                elif b.f == 2:
                    pyxel.blt(b.x,b.y+5,0,48,117,11,11,colkey=0)
                    if pyxel.frame_count%4 ==0:
                        b.f = 3
                elif b.f == 3:
                    pyxel.blt(b.x,b.y+5,0,64,101,11,11,colkey=0)
                    if pyxel.frame_count%4 ==0:
                        b.f = 4
                elif b.f == 4:
                    pyxel.blt(b.x,b.y+5,0,64,117,11,11,colkey=0)
                    if pyxel.frame_count%4 ==0:
                        b.f = 1
            ########
            #DONKEY#
            ########
            '''The donkey is everytime doing the animation of hitting his chest, everytime a barrel is spawned he does the animation
            of throwing it.'''
            if not self.donkey_is_active:
                if pyxel.frame_count%20<10:
                    pyxel.blt(26,6,0,48,64,48,32) 
                elif pyxel.frame_count%20>=10:
                    pyxel.blt(26,6,0,48,64,-48,32) 
            elif self.donkey_is_active:
                if (pyxel.frame_count-self.donkey_is_active[1])<10:
                    pyxel.blt(26,6,0,112,72,-48,32) 
                elif 30>=(pyxel.frame_count-self.donkey_is_active[1])>=10:
                    
                    pyxel.blt(26,6,0,112,72,48,32) 
                else:
                    self.donkey_is_active = False
                    
            ###PRINCESS###
            pyxel.blt(86,2,0,34,65,14,14,colkey=0) 
            
            ##BARRELS DONKEY UP##
            '''Decoration'''
            pyxel.blt(0,22,0,1,32,13,16) 
            pyxel.blt(0,8,0,1,32,14,16)
            pyxel.blt(13,22,0,1,32,13,16) 
            pyxel.blt(13,8,0,1,32,13,16) 
            

            
        #DIE SCREEN#
        '''Whenever luigi dies, it will switch to this screen where we will se the score made.'''
        if self.dieScreen == True:
            pyxel.blt(78,45,0,184,0,31,28)
            
            if pyxel.frame_count%20<=4:
                pyxel.blt(85,90,0,192,32,16,12)
            elif pyxel.frame_count%20<=9:
                pyxel.blt(85,100,0,192,32,16,12)
            elif pyxel.frame_count%20<=14:
                pyxel.blt(85,90,0,192,32,16,12)
            elif pyxel.frame_count%20<=19:
                pyxel.blt(85,80,0,192,32,16,12)
                    
            pyxel.blt(70,120,0,176,48,48,16)  
            
            pyxel.text(70,160,"PRESS R TO TRY AGAIN",10)
            pyxel.text(70,170,"PRESS Q TO EXIT",10)
            pyxel.text(70,150,'SCORE====> %i'%(self.score),10)
            '''Here we have of option of trying again'''
            if pyxel.btn(pyxel.KEY_R):
                self.gameScreen, self.dieScreen = True, False
                self.restartGame()
            
        ##WIN SCREEN#
        '''Whenever mario wins getting to Pauline, it will switch of to the winning screen where the score is printed and some animation
        of mario appears.'''
        if self.winScreen == True:
            if pyxel.frame_count%12<6:
                pyxel.blt(100,100,0,33,32,15,14,colkey=0)
            else:
                pyxel.blt(100,100,0,16,0,16,16,colkey=0)
            pyxel.text(60,150,"CONGRATULATIONS!",pyxel.frame_count%16)
            pyxel.blt(84,50,0,37,8,35,16)
            pyxel.blt(90,80,0,16,64,16,14,colkey=0)
            pyxel.text(91,57,"{:05}".format(self.score),10)
            pyxel.text(55,160,"PRESS R TO PLAY AGAIN",10)
            pyxel.text(55,170,"PRESS Q TO EXIT",10)
            pyxel.blt(60,116,0,0,128,80,8)
            pyxel.blt(80,95,0,48,24,17,27,colkey=0)
            ##RESTART THE GAME#
            '''Here we have of option of trying again'''
            if pyxel.btn(pyxel.KEY_R):
                self.gameScreen, self.winScreen = True, False
                self.restartGame()
Game()      
        
        
        
        
        
        
        

        
#        

