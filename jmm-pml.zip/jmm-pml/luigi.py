class Luigi:
    def __init__(self, x, y,limitY,plusY, lives, stairCondition):
        self.x = x
        self.y = y
        self.lives = lives
        self.limitY = limitY
        self.base1 = 216
        self.base2 = 176
        self.base3 = 138
        self.base4 = 100
        self.base5 = 62
        self.base6 = 25
        
            
        
    def move(self, d):
        'moving luigi left and right'
        if d == 'right':
            self.x += 2
        elif d == 'left':
            self.x -= 2
        return self.x
    
    def jump(self, y, plusY):
        '''jumping'''
        y += plusY
        '''When the plusY is set in the main file, we are using the min() function to make an accelerating jump up. 
        Whenever the min() is 0, luigi will stop and gravity will start affecting him. Returning luigi`s Y.'''
        plusY = min(plusY + 1, 0)
        return y, plusY
    
    def gravity(self, x, y):
        '''the effect of gravity. If it's not on top of a platform, it falls'''
        if y < self.limitY:
            y += 2
        return y, self.limitY
    
    def setStair(self,x,y,limitY,jc):
        '''detecting if luigi is on a stair using luigi's coordinates. If he is, gravity won´t affect him.'''
        if y <= limitY and (155 <= x <= 166) and (self.base2-2 < y <= self.base1) and not jc:
            self.stairCondition = True        
        elif y <= limitY and (28 <= x <= 38) and (self.base3-2 < y <= self.base2) and not jc:
           self.stairCondition = True           
        elif y <= limitY and (155 <= x <= 166) and (self.base4-2 < y <= self.base3) and not jc:
           self.stairCondition = True           
        elif y <= limitY and (28 <= x <= 38) and (self.base5-2 < y <= self.base4) and not jc:
           self.stairCondition = True           
        elif y <= limitY and (140 <= x <= 150) and (self.base6-1 <= y <= self.base5) and not jc:
           self.stairCondition = True          
        else:
            self.stairCondition = False
        return  self.stairCondition
    
    def climb(self, d ,y):
        'climbing stairs'
        if d == 'up':
            y -= 2
        if d == 'down':
            y += 2
        return y
    
    def setLimit(self, x, y):
        '''setting the limits for the y coordinates of luigi so that it doesn´t fall through platforms if luigi's x and y are a specific value,
        gravity doesn't apply, as he is on top of a platform'''
         ##set LIMIT
        if (self.base1 >= y > self.base2-2) or (self.base2 >= y >= self.base3 and x>174):
            self.limitY = 214
        elif (self.base3-2 < y <= self.base2-2) or (self.base3 >= y >= self.base4 and x<=18):
            self.limitY = 174
        elif (self.base4-2 < y <= self.base3-2) or (self.base4 >= y >= self.base5 and x>174):
            self.limitY = 136
        elif (self.base5-2 < y <= self.base4-2) or (self.base5 >= y >= self.base6 and x<=18):
            self.limitY = 98
        elif (self.base6 <= y <= self.base5-1) or (self.base6 >= y  and x > 160):
            self.limitY = 60
        elif ( y <= self.base6-1):
            self.limitY = 22   
        return self.limitY
    
    def kill(self, luigiX, luigiY, barrelX, barrelY):
        '''the collision of the barrel and luigi is calculated using coordinates. If luigi is dead, the method detects it and returns 'death' '''
        if barrelY<= luigiY+16 <=barrelY+11 and barrelX <= luigiX <= barrelX+11:
            return 'death'
        
    ##ScoreSystem
    def score(self,luigiX,luigiY,barrelX,barrelY):
        'adding points to the score'
        if luigiX==barrelX and ((abs(luigiY-barrelY))<=15):
            return 200
        
        
        


